import cv2
import numpy as np

resim = np.zeros((300,300,3),dtype="uint8") #verilenlere göre matris oluşturur. Elemanlar 0 olur çünkü zeros kullanıldı.

print(resim)

cv2.waitKey()
cv2.destroyAllWindows()




















